package com.sp.top_songs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TopSongsApplication {

	public static void main(String[] args) {

		SpringApplication.run(TopSongsApplication.class, args);
	}

}
