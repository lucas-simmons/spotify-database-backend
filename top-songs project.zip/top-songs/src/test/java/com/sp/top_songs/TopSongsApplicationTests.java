package com.sp.top_songs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TopSongsApplicationTests {

	@Test
	void contextLoads() {
	}

}
